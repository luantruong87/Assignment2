//
//  ClaimStoryboardController.swift
//  SimpleHTTPClient1
//
//  Created by luan nguyen on 11/25/20.
//  Copyright © 2020 ITLoaner. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    @IBOutlet weak var val1: UITextField!
    
    @IBOutlet weak var val2: UITextField!
    
    @IBOutlet weak var addbtn: UIButton!
    
    @IBOutlet weak var vall: UITextField!
    
    var cService : ClaimServiceStoryboard!
    
    func dataCheck() -> Bool {
        var checked : Bool = true
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy MM-dd"
        if dateFormatterGet.date(from: val2.text!) != nil {
            //checked = true
        }else {
            checked = false
            print("your date  must follow the format 'yyyy MM-dd'")
        }
        //print(vals[1].text!)
        
        if val1.text!.count > 0{
            
        } else{
            checked = false
            print("Your Claim Title cannot be blank")
        }
        return checked
        
    }
    
    func statusMessage(resp: String){
        if resp == "The Claim record was successfully inserted (via POST Method)." {
            vall.text = "Claim \(val1.text!) was successfully created"
        } else {
            vall.text = "Claim \(val1.text!) failed to be created"
            
        }
        
        val1.text = ""
        val2.text = ""
    }
    
    func refreshScreen(sresp: String){
        statusMessage(resp: sresp)
    }
    
    @objc func addClaimToDB(sender: UIButton) {
        cService = ClaimServiceStoryboard(vc : self)
        let checked = dataCheck()
        if checked == true {
            cService.addClaim(pObj: Claimate(title: val1.text! ,date: val2.text!))
        } else {
            statusMessage(resp: "failed")
        }

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        val1.delegate = self
        val2.delegate = self
        vall.delegate = self
        
        addbtn.addTarget(self, action: #selector(addClaimToDB(sender:)), for: .touchUpInside)
    }
    
}

extension ViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
